"""Package this experiment's immutable evidence; run from the repository root."""

import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

REPO = Path.cwd()
ROOT = REPO / ".stericx/profiling"
OPT = ROOT / "optimization"
DOCS = REPO / "docs/profiling"


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


labels = [
    "baseline_final_t1", "baseline_final_t6",
    "optimization_control_t1", "optimization_control_t6",
    "candidate1_t1", "candidate1_t6", "candidate1_diagnostic_t1",
    "optimization_control_sep19_t1", "optimization_control_sep19_t6",
    "candidate2_t1", "candidate2_t6", "candidate2_diagnostic_t1",
]
runs = {label: read(ROOT / "runs" / label / "summary.json") for label in labels}
manifest_sha = sha(ROOT / "workloads/manifest.json")
for label, run in runs.items():
    assert run["status"] == "complete", label
    assert run["manifest_sha256"] == manifest_sha, label
    # CLI output includes the requested thread count; compare matching settings.
    reference = runs["baseline_final_t6" if label.endswith("_t6") else "baseline_final_t1"]
    for name, result in run["results"].items():
        assert result["fingerprints"] == reference["results"][name]["fingerprints"], (label, name)

identity = read(OPT / "candidate2/identity.json")
for name, expected in identity["source_files"].items():
    assert sha(REPO / name) == expected, name
for name, expected in identity["binaries"].items():
    assert sha(OPT / "candidate2" / name) == expected["sha256"], name

tables = {}
for threads in (1, 6):
    control = runs[f"optimization_control_sep19_t{threads}"]
    final = runs[f"candidate2_t{threads}"]
    assert control["affinity"] == final["affinity"]
    assert control["environment"] == final["environment"]
    assert control["repetitions"] == final["repetitions"] == 7
    rows = {}
    for name, result in final["results"].items():
        summaries = {
            label: runs[label]["results"][name]["summary"]
            for label in labels
            if label.endswith(f"_t{threads}") and "diagnostic" not in label
        }
        before = control["results"][name]["summary"]["wall_ns"]["median"]
        after = result["summary"]["wall_ns"]["median"]
        original = runs[f"baseline_final_t{threads}"]["results"][name]["summary"]["wall_ns"]["median"]
        rows[name] = dict(
            all_scientific_fingerprints_equal=True,
            scientific_fingerprints=result["fingerprints"],
            speedup_vs_contemporaneous_control=before / after,
            wall_reduction_fraction=1 - after / before,
            speedup_vs_september16_measurement=original / after,
            summaries=summaries,
        )
    tables[f"threads_{threads}"] = rows

paired = {str(p.parent.relative_to(ROOT)): read(p) for p in (ROOT / "runs").glob("candidate*_paired*/summary.json")}
oracles = {}
for name in ("error_oracles", "volume_oracles"):
    checks = {}
    for threads in (1, 6):
        p = OPT / name / "comparisons" / f"candidate2_t{threads}" / "summary.json"
        checks[str(threads)] = read(p)
        assert checks[str(threads)]["status"] == "complete"
    oracles[name] = dict(manifest=read(OPT / name / "manifest.json"), comparisons=checks)
prediction = read(OPT / "prediction_audit_candidate2/summary.json")
assert prediction["status"] == "complete" and prediction["all_bitwise_equal"]
summary = dict(
    manifest_sha256=manifest_sha,
    final_identity=identity,
    native_tables=tables,
    paired_followups=paired,
    native_method="Seven measured warm-cache process launches after one warmup, exact-child wait4, process startup and regular-file output included. No builds or profilers overlap native series.",
    exactness_oracles=oracles,
    full_prediction_audit=prediction,
    production_operation_counts=read(OPT / "occupancy_probe_v2_aggregate.json"),
    original_strict_early_exits=read(OPT / "occupancy_strict_early_exits.json"),
    compiled_event_comparison=read(OPT / "candidate2_occupancy_cache_comparison.json"),
    completion_audit=read(OPT / "completion_audit.json"),
    verification={p.stem: read(p) for p in (OPT / "verification_sep19").glob("*.json")},
)
save(DOCS / "optimization_summary.json", summary)

# Retain every per-launch measurement/trace, plus representative full outputs.
# Binary hashes are retained; executable/build caches and repeated output copies
# are omitted. The original input-generation manifest is already distributed.
files = set()
for label in labels + [Path(name).name for name in paired]:
    directory = ROOT / "runs" / label
    files.update(directory.rglob("*.json"))
    for p in directory.rglob("measured_00/*"):
        if p.is_file():
            files.add(p)
for name in ("error_oracles", "volume_oracles", "prediction_audit_candidate2", "verification_sep19"):
    directory = OPT / name
    files.update(p for p in directory.rglob("*") if p.is_file() and p.suffix != ".f32")
for name in ("baseline_source", "candidate1/source", "candidate2/source"):
    files.update(p for p in (OPT / name).rglob("*") if p.is_file())
for name in ("freeze.json", "candidate1/identity.json", "candidate2/identity.json"):
    files.add(OPT / name)
files.update(p for p in OPT.glob("*") if p.is_file() and p.suffix in (".json", ".py", ".gz", ".rs"))
files.update((OPT / "occupancy_probe_v2_results").rglob("*.json.gz"))
files.update((OPT / "occupancy_probe_v2_results").rglob("result.json"))
files.update((OPT / "candidate2_profile_summary").rglob("*.json"))
files.update(REPO / "scripts" / name for name in (
    "profile_stericx.py", "profile_child.c", "profile_valgrind.py", "summarize_profile.py",
    "check_screening_exactness.py", "check_volume_exactness.py",
))
files.update(REPO.glob("tests/test_profile*.py"))
files.add(REPO / "tests/test_screening_exactness.py")
files.add(REPO / "examples/profile_predictions.rs")
files.add(REPO / ".github/workflows/ci.yml")
files.add(OPT / "build_optimization_report.py")
manifest = {str(p.relative_to(REPO)): {"bytes": p.stat().st_size, "sha256": sha(p)} for p in sorted(files)}
archive = DOCS / "optimization_evidence.tar.gz"
with archive.open("wb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as compressed, tarfile.open(fileobj=compressed, mode="w|") as tar:
    for p in sorted(files):
        data = p.read_bytes()
        info = tarfile.TarInfo(str(p.relative_to(REPO)))
        info.size = len(data)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
    data = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    info = tarfile.TarInfo("EVIDENCE_SHA256.json")
    info.size = len(data)
    info.mode = 0o644
    tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, "r:gz") as tar:
    assert len(tar.getmembers()) == len(files) + 1
    for name, expected in manifest.items():
        data = tar.extractfile(name).read()
        assert len(data) == expected["bytes"]
        assert hashlib.sha256(data).hexdigest() == expected["sha256"]
save(DOCS / "optimization_evidence_identity.json", dict(archive_sha256=sha(archive), archive_bytes=archive.stat().st_size, files=len(files), content_manifest=manifest))
print("Verified", len(files), "archived files;", archive.stat().st_size, "compressed bytes")
