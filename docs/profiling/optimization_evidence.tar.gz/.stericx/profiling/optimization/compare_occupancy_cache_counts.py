#!/usr/bin/env python3
"""Compare equal-scope whole-workload Cachegrind events and expose hot functions."""
from collections import Counter, defaultdict
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('.stericx/profiling')
EVENTS = ('Ir', 'I1mr', 'ILmr', 'Dr', 'D1mr', 'DLmr', 'Dw', 'D1mw', 'DLmw', 'Bc', 'Bcm', 'Bi', 'Bim')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def extract(directory, native):
    path = directory / 'events.out'
    functions = defaultdict(Counter)
    by_source = defaultdict(lambda: defaultdict(Counter))
    total = Counter()
    events = function = source = summary = None
    for line in path.read_text().splitlines():
        if line.startswith('events:'):
            assert events is None
            events = line.split()[1:]
            assert tuple(events) == EVENTS
        elif line.startswith('fl='):
            source = line[3:]
        elif line.startswith('fn='):
            function = line[3:]
        elif line.startswith('summary:'):
            assert summary is None
            summary = dict(zip(events, map(int, line.split()[1:]), strict=True))
        elif line[:1].isdigit():
            values = list(map(int, line.split()[1:]))
            assert len(values) <= len(events) and source is not None and function is not None
            values += [0] * (len(events)-len(values))
            row = dict(zip(events, values, strict=True))
            total.update(row)
            functions[function].update(row)
            by_source[function][source].update(row)
    assert dict(total) == summary
    assert summary == native['counts']
    annotation = (directory / 'functions.txt').read_text()
    annotation_functions = {}
    for line in annotation.splitlines():
        if line.startswith('>'):
            cleaned = re.sub(r'\([\d., %]+\)', '', line)
            fields = cleaned.split(None, 14)
            assert len(fields) == 15 and ':' in fields[-1]
            # cg_annotate condenses single-source functions to function:file.
            # The final colon is the separator; Rust namespace colons remain.
            name = fields[-1].rsplit(':', 1)[0]
            assert name not in annotation_functions
            annotation_functions[name] = [int(s.replace(',', '')) for s in fields[1:14]]
    annotation_checks = []
    for name, counts in functions.items():
        if name in annotation_functions:
            assert annotation_functions[name] == [counts[e] for e in events], name
            annotation_checks.append(name)
    hot = sorted(functions.items(), key=lambda item:item[1]['Ir'], reverse=True)
    original = '<steric_x::geometry::buried_volume::BuriedVolumeCalculator>::compute_from_center'
    occupancy = 'steric_x::geometry::buried_volume::occupied_volumes'
    for name in (original, occupancy):
        if functions.get(name, {}).get('Ir', 0) > total['Ir'] * 0.001:
            assert name in annotation_checks
    return {
        'events_sha256': digest(path), 'annotation_sha256': digest(directory / 'functions.txt'),
        'program_counts': summary, 'raw_rows_sum_matches_summary': True,
        'function_totals_checked_against_cg_annotate': annotation_checks,
        'hot_functions_self_counts': [{'function': name, 'events': dict(events), 'instruction_fraction': events['Ir']/total['Ir']} for name,events in hot[:20]],
        'buried_volume_functions_self_counts_by_inlined_source': {name:{source:dict(counts) for source,counts in files.items()} for name,files in by_source.items() if 'buried_volume' in name},
        'function_scope': 'Function self-cost, including code inlined into that function, excluding non-inlined callees. Original occupancy was inlined into compute_from_center; final occupied_volumes is separately emitted. Individual function costs therefore have different scopes and are not used as the speedup comparison.',
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-label', default='candidate2_cachegrind_sep19')
    args = parser.parse_args()
    baseline_path = ROOT / 'valgrind/baseline_cachegrind_configured'
    candidate_path = ROOT / 'valgrind' / args.candidate_label
    before = json.loads((baseline_path / 'summary.json').read_text())
    after = json.loads((candidate_path / 'summary.json').read_text())
    assert before['status'] == after['status'] == 'complete'
    assert before['cache_configuration'] == after['cache_configuration']
    assert before['manifest_sha256'] == after['manifest_sha256']
    assert before['valgrind_binary_sha256'] == after['valgrind_binary_sha256']
    assert before['affinity'] == after['affinity'] == [2]
    comparisons = {}
    evidence = []
    for name in ('conformers_56', 'descriptors_10000'):
        baseline = before['results'][name]
        candidate = after['results'][name]
        assert baseline['exact_scientific_output_match'] and candidate['exact_scientific_output_match']
        assert baseline['fingerprints'] == candidate['fingerprints']
        old = extract(baseline_path / name, baseline)
        new = extract(candidate_path / name, candidate)
        comparisons[name] = {
            'scientific_outputs_exact': True,
            'baseline': old, 'candidate': new,
            'whole_workload_event_comparison': {event:{'baseline':old['program_counts'][event], 'candidate':new['program_counts'][event], 'candidate_over_baseline':new['program_counts'][event]/old['program_counts'][event] if old['program_counts'][event] else None} for event in EVENTS},
        }
        for filename in ('events.out', 'functions.txt', 'annotation.stderr.txt', 'stdout.txt', 'stderr.txt', 'command.json', 'profiler.log', 'run.json', 'summary.json'):
            path = candidate_path / name / filename
            if path.exists():
                raw = path.read_bytes()
                evidence.append({'path':str(path.relative_to(ROOT)), 'sha256':hashlib.sha256(raw).hexdigest(), 'text':raw.decode()})
    report = {
        'schema_version': 1, 'baseline_label': baseline_path.name,
        'candidate_label': candidate_path.name,
        'baseline_summary_sha256': digest(baseline_path / 'summary.json'),
        'candidate_summary_sha256': digest(candidate_path / 'summary.json'),
        'baseline_binary_sha256': before['binary_sha256'], 'candidate_binary_sha256': after['binary_sha256'],
        'workload_manifest_sha256': before['manifest_sha256'],
        'cache_geometry': before['cache_configuration'],
        'method': 'Same complete native workload arguments/inputs, optimized symbol binaries without profiling feature, one Rayon thread on CPU2, fixed Valgrind tool and I1/D1/LL geometry. Whole-program event counts compare equal scope; individual hot functions expose changed inlining boundaries.',
        'caveats': [
            'Cachegrind Dr/Dw are instrumented data-reference counts; they are not native hardware loads/stores. Read-modify-write counts only as a read and REP iterations count separately.',
            'Cache and branch misses are simulations, not measured native CPU hardware counters.',
            'Instruction/data/branch event counts have no wall-time units and do not establish native speedup. Native results are separately measured without a profiler.',
            'Function costs are self counts across all inlined source locations; compiler extraction/inlining changes their scope, so only whole-program counts are compared.',
        ],
        'primary_documentation': 'https://valgrind.org/docs/manual/cg-manual.html#cg-manual.simulation',
        'results': comparisons,
    }
    output = ROOT / 'optimization/candidate2_occupancy_cache_comparison.json'
    save(output, report)
    evidence.append({'path':str((candidate_path / 'summary.json').relative_to(ROOT)), 'sha256':digest(candidate_path / 'summary.json'), 'text':(candidate_path / 'summary.json').read_text()})
    archive = ROOT / 'optimization/candidate2_cachegrind_evidence.json.gz'
    raw = (json.dumps({'files':evidence}, sort_keys=True, separators=(',', ':'))+'\n').encode()
    packed = gzip.compress(raw, compresslevel=9, mtime=0)
    archive.write_bytes(packed)
    assert gzip.decompress(archive.read_bytes()) == raw
    save(ROOT / 'optimization/candidate2_cachegrind_evidence_integrity.json', {
        'files':len(evidence), 'archive_sha256':digest(archive), 'archive_bytes':len(packed),
        'comparison_sha256':digest(output), 'raw_artifact_sha256_verified':True,
        'baseline_evidence': 'Original baseline is already retained in docs/profiling/profiler_evidence.json.gz and .stericx/profiling/valgrind/baseline_cachegrind_configured.',
    })
    print(json.dumps({name:r['whole_workload_event_comparison'] for name,r in comparisons.items()}, indent=2))


if __name__ == '__main__':
    main()
