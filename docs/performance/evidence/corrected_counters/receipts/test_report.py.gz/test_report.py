"""Guard the annotation's two presentations against duplicate attribution."""

import tempfile
import unittest
from pathlib import Path

import report


def row(prefix, count, name):
    return prefix + " " + str(count) + " (10.0%, 20.0%) " + "0 " * 12 + name


class AnnotationTests(unittest.TestCase):
    def parse(self, lines):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "annotation.txt"
            path.write_text("\n".join(lines))
            return report.instruction_functions(path)

    def test_totals_not_both_detailed_presentations(self):
        actual = self.parse(
            [
                "-- File:function summary",
                row("<", 70, "/src/example.rs:"),
                row(" ", 70, "example::calculate"),
                "-- Function:file summary",
                row(">", 100, "example::calculate:"),
                row(" ", 70, "/src/example.rs"),
                row(" ", 30, "/src/inline.rs"),
                row(">", 20, "malloc:./malloc.c"),
            ]
        )
        self.assertEqual(
            actual,
            [
                {"function": "example::calculate", "instructions": 100},
                {"function": "malloc", "instructions": 20},
            ],
        )

    def test_duplicate_totals_fail(self):
        with self.assertRaisesRegex(ValueError, "duplicate"):
            self.parse(
                ["-- Function:file summary", row(">", 1, "f:"), row(">", 2, "f:")]
            )

    def test_truncated_total_fails(self):
        with self.assertRaisesRegex(ValueError, "invalid"):
            self.parse(["-- Function:file summary", "> 100 0 0 f:"])


if __name__ == "__main__":
    unittest.main()
