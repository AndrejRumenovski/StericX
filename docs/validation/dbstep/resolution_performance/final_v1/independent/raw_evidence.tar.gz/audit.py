"""Read-only post-hoc audit; no scientific kernel or measurement calls."""
import datetime, hashlib, json, pathlib, statistics, sys
ROOT=pathlib.Path.cwd(); OUT=ROOT/'.stericx/dbstep_resolution/performance_independent_v1'; RAW=ROOT/'.stericx/dbstep_resolution/performance_v1'
sys.path.insert(0,str(ROOT/'scripts'))
import profile_stericx as profile

def read(p):return json.loads(pathlib.Path(p).read_text())
def record(p):
 p=pathlib.Path(p)
 with p.open('rb') as f: h=hashlib.file_digest(f,'sha256').hexdigest()
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
def verify(item):
 now=record(item['path']); assert now['bytes']==item['bytes'] and now['sha256']==item['sha256'],item
journal=read(RAW/'journal.json'); summary=read(RAW/'native/summary.json'); review=read(ROOT/'.stericx/dbstep_resolution/performance_review_v1/review.json')
assert journal['complete'] and summary['complete']
for item in journal['bindings']+summary['bindings']+list(summary['binaries'].values()):verify(item)
assert summary['affinities']=={'1':'2','2':'2,3','4':'0,1,2,3','6':'0,1,2,3,4,5'}
for c in journal['commands']:
 assert c['returncode']==0
 verify(c['log'])
 for item in c.get('produced_records',[]):verify(item)
workloads=read(next(x['path'] for x in summary['bindings'] if x['path'].endswith('workloads/manifest.json')))['workloads']
expected=[]
names=['single_small','single_large','ensemble_sdf','conformers_56','descriptors_10000','parse_ensembles_1000','db_build_ensembles']
for t in (1,2,4,6):
 for name in names:
  expected += [(t,name,'warmup',0,side) for side in ('baseline','candidate')]
  for pair in range(8):expected += [(t,name,'measured',pair,side) for side in (('baseline','candidate') if pair%2==0 else ('candidate','baseline'))]
actual=[tuple(a[k] for k in ('threads','workload','phase','pair','side')) for a in summary['attempts']]
assert actual==expected and len(actual)==504
rows=[]; groups={}; all_metrics=[]
for a in summary['attempts']:
 assert a['status']=='complete';verify(a['metrics']);m=read(a['metrics']['path']);d=pathlib.Path(a['directory'])
 assert m['returncode']==0
 assert all(m[k]==a[k] for k in ('phase','pair','side'))
 fp={**profile.check_result(workloads[a['workload']],d),'stderr_sha256':record(d/'stderr.txt')['sha256']}
 assert fp==m['fingerprints']==summary['results'][str(a['threads'])][a['workload']]['fingerprints']
 assert record(d/'stdout.txt')['sha256']==m['raw_stdout_sha256']
 assert record(d/'stderr.txt')['sha256']==m['raw_stderr_sha256']
 groups.setdefault((a['threads'],a['workload']),[]).append(m);all_metrics.append(m)
for (t,name),ms in groups.items():
 measured=[m for m in ms if m['phase']=='measured'];data={s:[m for m in measured if m['side']==s] for s in ('baseline','candidate')}
 assert all(len(v)==8 for v in data.values())
 med={s:statistics.median(m['wall_ns'] for m in v) for s,v in data.items()}
 pair_ratios=[]
 for i in range(8):
  pair={m['side']:m for m in measured if m['pair']==i};assert len(pair)==2;pair_ratios.append(pair['baseline']['wall_ns']/pair['candidate']['wall_ns'])
 ratio=med['candidate']/med['baseline'];paired=statistics.median(pair_ratios)
 expected_summary=summary['results'][str(t)][name]
 for s in data:
  assert med[s]==expected_summary[s]['wall_ns']['median']
  vals=[m['wall_ns'] for m in data[s]]
  assert expected_summary[s]['wall_ns']['minimum']==min(vals) and expected_summary[s]['wall_ns']['maximum']==max(vals)
  assert expected_summary[s]['wall_ns']['mad']==statistics.median(abs(v-med[s]) for v in vals)
  assert expected_summary[s]['records_per_second']==workloads[name]['expected_records']*1e9/med[s]
 rss={s:statistics.median(m['peak_rss_bytes'] for m in v) for s,v in data.items()}
 row={'threads':t,'workload':name,'baseline_wall_median_ns':med['baseline'],'candidate_wall_median_ns':med['candidate'],'candidate_over_baseline_wall_median':ratio,'median_within_pair_baseline_over_candidate':paired,'trigger':ratio>1.1 or paired<1/1.1,'rss_medians_bytes':rss,'candidate_over_baseline_rss_median':rss['candidate']/rss['baseline'],'records_per_second':{s:workloads[name]['expected_records']*1e9/med[s] for s in data}}
 rows.append(row)
allocation_rows=[]
for a in summary['allocations']:
 verify(a['report']);d=pathlib.Path(a['report']['path']).parent;assert read(a['report']['path'])['allocations']==a['allocations']
 fp={**profile.check_result(workloads[a['workload']],d),'stderr_sha256':record(d/'stderr.txt')['sha256']}
 assert fp==summary['results'][str(a['threads'])][a['workload']]['fingerprints'];assert a['allocations']['failed_allocation_calls']==0
allocation_map={}
for a in summary['allocations']:allocation_map.setdefault((a['threads'],a['workload']),{})[a['side']]=a['allocations']
assert len(allocation_map)==14
for (t,w),pair in allocation_map.items():
 assert set(pair)=={'baseline','candidate'}
 for key in ['allocation_calls','reallocation_calls','deallocation_calls','failed_allocation_calls']:assert pair['baseline'][key]==pair['candidate'][key]
 allocation_rows.append({'threads':t,'workload':w,'requested_byte_delta':pair['candidate']['requested_bytes']-pair['baseline']['requested_bytes'],'peak_requested_byte_delta':pair['candidate']['peak_live_requested_bytes']-pair['baseline']['peak_live_requested_bytes']})
assert journal['python_campaign_order']==['baseline','candidate','candidate','baseline'];py={s:{m:[] for m in ['native','bridge','public']} for s in ['baseline','candidate']};preflight=None
for i,side in enumerate(journal['python_campaign_order']):
 d=RAW/f'python_{i}_{side}';s=read(d/'summary.json');assert s['complete'] and s['scientific_results_exact'] and s['iterations_per_block']==100 and s['affinity']==[2]
 for item in s['bindings']:verify(item)
 result=read(d/'bridge_preflight.json')
 if preflight is None:preflight=result
 assert result==preflight==read(d/'native_preflight.json')['result']
 schedule=[(p,m) for p in range(8) for m in (['native','bridge','public'] if p%2==0 else ['public','bridge','native'])]
 assert [(a['pair'],a['method']) for a in s['attempts']]==schedule
 for a in s['attempts']:
  assert a['status']=='complete' and a['elapsed_ns']>0;py[side][a['method']].append(a['elapsed_ns']/100)
  if a['method']=='native':
   n=read(d/f"native_{a['pair']}.json");assert n['result']==preflight and n['elapsed_ns']==a['elapsed_ns'] and n['iterations']==100
python_rows=[]
for method in ['native','bridge','public']:
 assert all(len(py[s][method])==16 for s in py)
 med={s:statistics.median(py[s][method]) for s in py};ratio=med['candidate']/med['baseline']
 python_rows.append({'method':method,'median_ns_per_call':med,'candidate_over_baseline':ratio,'trigger':ratio>1.1})
for row in journal['ensemble_allocation_runs']:
 verify(row['stdout']);verify(row['metrics']);assert read(row['stdout']['path'])==row['values'];assert read(row['metrics']['path'])['returncode']==0
ens={r['side']:r['values'] for r in journal['ensemble_allocation_runs']}
for key in ['allocation_calls','reallocation_calls','deallocation_calls','failed_allocation_calls','requested_bytes','live_requested_bytes_delta']:
 assert ens['baseline'][key]==ens['candidate'][key]
before,after=journal['host_before'],journal['host_after'];elapsed=(datetime.datetime.fromisoformat(after['utc'])-datetime.datetime.fromisoformat(before['utc'])).total_seconds()
psi={}
for name in ['cpu','io','memory']:
 def parse(s):return {line.split()[0]:int(line.split('total=')[1]) for line in s.splitlines()}
 b,a=[parse(h['proc']['pressure/'+name]) for h in [before,after]]
 psi[name]={k:{'total_delta_microseconds':a[k]-b[k],'percent_elapsed':(a[k]-b[k])/1e6/elapsed*100} for k in a}
# /proc/stat CPU counts are aggregate cumulative ticks: percentages need no HZ.
b=[int(x) for x in before['proc']['stat'].splitlines()[0].split()[1:]];a=[int(x) for x in after['proc']['stat'].splitlines()[0].split()[1:]];delta=[x-y for x,y in zip(a,b)];total=sum(delta[:8]);cpu={'idle_percent':delta[3]/total*100,'iowait_percent':delta[4]/total*100,'nonidle_non_iowait_percent':(total-delta[3]-delta[4])/total*100}
report={'kind':'independent_read_only_performance_audit','source_records':[record(RAW/'journal.json'),record(RAW/'native/summary.json'),record(ROOT/'.stericx/dbstep_resolution/performance_review_v1/review.json'),record(__file__)],'native_attempts':504,'native_schedule_exact':True,'native_raw_fingerprints_checked':504,'instrumented_raw_fingerprints_checked':28,'all_native_outputs_equal':True,'native_rows':rows,'native_triggers':[r for r in rows if r['trigger']],'python_block_attempts':96,'python_schedule_exact':True,'python_preflights_and_native_measured_outputs_equal':True,'python_rows':python_rows,'python_triggers':[r for r in python_rows if r['trigger']],'allocation_counts_exact_all_14_pairs':True,'allocation_rows':allocation_rows,'warmed_ensemble_allocation_counts_and_requested_bytes_exact':True,'host_duration_seconds':elapsed,'host_pressure_deltas':psi,'host_aggregate_cpu_delta':cpu,'maximum_native_rss_median_increase_percent':100*(max(r['candidate_over_baseline_rss_median'] for r in rows)-1),'major_page_faults_all_native_attempts':sum(m['major_faults'] for m in all_metrics),'performance_admissible':not any(r['trigger'] for r in rows+python_rows),'limitations':['Only this finite frozen workload schedule is measured. No algorithmic speedup/slowdown inferred for byte-identical binaries.','Before/after process CPU percentages are lifetime averages and do not establish instantaneous interference. Pressure counters include benchmark I/O/CPU.','Python bridge/public equality is verified at preflight; native output is additionally verified per timed block, following the frozen protocol.','Requested-byte differences include argv path lengths; six-thread peak live storage can vary with scheduling. Per-child RSS is distinct from allocator storage.','This performance audit does not itself admit a release; scientific and packaging gates require separate review.']}
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['native_triggers','python_triggers','performance_admissible','host_duration_seconds','host_pressure_deltas','host_aggregate_cpu_delta','maximum_native_rss_median_increase_percent','major_page_faults_all_native_attempts']},indent=2))
