"""Summarize completed unchanged baseline workloads; modeled counts only."""

import json
import re
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
REPO = BASE.parents[2]
SNAPSHOT = BASE / "accurate_baseline_v1"
WORK = BASE / "corrected_workloads_v2"
sys.path.insert(0, str(SNAPSHOT / "source/scripts"))
import profile_valgrind as vg  # noqa: E402
import scientifically_exact_optimization as exact  # noqa: E402


def instruction_functions(path):
    """Read the function totals, excluding repeated file/function detail rows."""
    token = re.compile(r"\s*([0-9][0-9,]*)(?:\s+\([^)]*\))?")
    result = {}
    in_functions = False
    for line in path.read_text().splitlines():
        if line == "-- Function:file summary":
            in_functions = True
        if not in_functions or not line.startswith(">"):
            continue
        offset, values = 1, []
        for _ in vg.CACHE_EVENTS:
            match = token.match(line, offset)
            if match is None:
                break
            values.append(int(match[1].replace(",", "")))
            offset = match.end()
        name = line[offset:].strip()
        if len(values) != len(vg.CACHE_EVENTS) or not name:
            raise ValueError("invalid annotated function total")
        # A one-file function has a :path suffix; multi-file totals end in :.
        name = re.split(r":(?=[/.])", name, maxsplit=1)[0].removesuffix(":")
        if name in result:
            raise ValueError("duplicate annotated function total")
        result[name] = values[0]
    return sorted(
        [{"function": name, "instructions": count} for name, count in result.items()],
        key=lambda row: row["instructions"],
        reverse=True,
    )


def allocation_sites(path):
    raw = exact.oracle.read(path)
    rows = []
    for point in raw["pps"]:
        stack = [raw["ftbl"][index] for index in point["fs"]]
        application = [
            frame for frame in stack if "steric_x::" in frame or "stericx::" in frame
        ]
        rows.append(
            {
                "requested_bytes": point["tb"],
                "allocation_blocks": point["tbk"],
                "application_frames": application,
                "full_stack": stack,
                "integration_grid_stack": any(
                    "integration_grid" in frame for frame in stack
                ),
            }
        )
    return sorted(rows, key=lambda row: row["requested_bytes"], reverse=True)


def main():
    capabilities = exact.replay.load_manifest(OUT / "capabilities.json")
    bindings = [
        exact.oracle.file_record(path)
        for path in (
            OUT / "capabilities.json",
            BASE / "counter_capabilities_v1/manifest.json",
            BASE / "accurate_baseline_v1_diagnostics/builds.json",
            SNAPSHOT / "manifest.json",
            WORK / "workloads/manifest.json",
            WORK / "runs/accurate_baseline_native_t1/summary.json",
            Path(__file__),
            OUT / "test_report.py",
            OUT / "report_checks.json",
            SNAPSHOT / "source/scripts/profile_valgrind.py",
            BASE.parent / "tools/valgrind/usr/share/doc/valgrind/html/cg-manual.html",
            BASE.parent / "tools/valgrind/usr/share/doc/valgrind/html/dh-manual.html",
        )
    ]
    rows = []
    for tool in ("cachegrind", "dhat"):
        for suffix, workload in (
            ("conformers56", "conformers_56"),
            ("screen1000", "screen_1000"),
            ("descriptors10000", "descriptors_10000"),
        ):
            root = WORK / "valgrind" / f"accurate_baseline_{tool}_{suffix}_v1"
            controller = exact.oracle.read(root / "summary.json")
            if controller["status"] != "complete" or controller["workloads"] != [
                workload
            ]:
                raise ValueError("modeled workload did not complete unchanged")
            run = root / workload
            summary = exact.oracle.read(run / "summary.json")
            if summary.get("exact_scientific_output_match") is not True:
                raise ValueError("modeled output did not match native")
            native = exact.oracle.read(
                WORK / "runs/accurate_baseline_native_t1/summary.json"
            )
            case = exact.oracle.read(WORK / "workloads/manifest.json")["workloads"][
                workload
            ]
            vg.check_against_native(
                case, run, native["results"][workload]["fingerprints"]
            )
            for name, wanted in summary["artifacts"].items():
                if exact.oracle.sha(run / name) != wanted:
                    raise ValueError("raw profiler artifact changed")
            raw_bindings = [
                exact.oracle.file_record(path)
                for path in sorted(root.rglob("*"))
                if path.is_file()
            ]
            bindings += raw_bindings
            row = {
                "tool": tool,
                "workload": workload,
                "summary": summary,
                "controller_summary": exact.oracle.file_record(root / "summary.json"),
            }
            if tool == "cachegrind":
                row["functions_by_instructions"] = instruction_functions(
                    run / "functions.txt"
                )
                if (
                    sum(f["instructions"] for f in row["functions_by_instructions"])
                    > summary["counts"]["Ir"]
                ):
                    raise ValueError("instruction attribution double counts totals")
            else:
                sites = allocation_sites(run / "dhat.json")
                if (
                    sum(site["requested_bytes"] for site in sites)
                    != summary["total_requested_bytes"]
                ):
                    raise ValueError("heap site attribution is incomplete")
                row["top_allocation_sites"] = sites[:10]
                row["integration_grid_requested_bytes"] = sum(
                    site["requested_bytes"]
                    for site in sites
                    if site["integration_grid_stack"]
                )
            rows.append(row)
    for binding in bindings:
        exact.oracle.verify(binding)
    data = {
        "kind": "corrected_baseline_modeled_counters",
        "complete": True,
        "native_hardware_measurement": False,
        "native_speedup_claim": False,
        "baseline_commit": "1ecfbd5be8b354711bdadd8a8d148417e03d8e7a",
        "threads": 1,
        "affinity": [2],
        "bindings": bindings,
        "rows": rows,
        "all_six_unchanged_workloads_exact_native_output": True,
        "excluded_workloads": [
            "single_small",
            "single_large",
            "ensemble_sdf",
            "parse_ensembles_1000",
            "predict_1000000",
            "search_database",
            "db_build_ensembles",
        ],
    }
    exact.replay.manifest(OUT / "manifest.json", data)
    target = REPO / "docs/performance/current_corrected_counters.json"
    with target.open("x") as stream:
        json.dump(data, stream, separators=(",", ":"), allow_nan=False)
        stream.write("\n")
    lines = [
        "# Corrected baseline modeled counter and heap investigation",
        "",
        "Cachegrind and DHAT completed the unchanged `conformers_56`, `screen_1000` "
        "and `descriptors_10000` workloads on the frozen corrected baseline, each at "
        "one Rayon thread pinned to CPU2. All six outputs match the corresponding "
        "native fingerprints exactly. No workload was reduced or extrapolated into "
        "a claimed full-workload result. The other seven workload types were not "
        "profiled by these tools in this investigation.",
        "",
        "The executable is the uninstrumented symbol build from corrected commit "
        "`1ecfbd5be8b354711bdadd8a8d148417e03d8e7a`, bound to the frozen baseline "
        "source and builds receipt. The profiling-feature allocator/timers are absent. "
        "Native wall/CPU/RSS results remain in "
        "[CORRECTED_PROFILE.md](CORRECTED_PROFILE.md); "
        "these profiler runs neither measure native speedups nor compare C1.",
        "",
        "Fresh hardware-event probes were denied (`perf_event_paranoid=4`). No "
        "privileges were changed. The retained local Valgrind installation was "
        "freshly checked: "
        + capabilities["tool_version"]
        + ", both tool/preload paths and "
        "actual executable probes succeeded. Tool, source, input, binary, output, "
        "native-oracle and helper identities are in [the complete counter data]"
        "(current_corrected_counters.json).",
        "",
        "## Modeled instructions, data references, branches and caches",
        "",
        "Cachegrind explicitly models 32 KiB, 8-way, 64-byte-line I1 and D1 caches "
        "and a 16 MiB, 16-way, 64-byte-line unified last-level cache, using freshly "
        "read CPU2 sysfs geometry. Intermediate L2 is not modeled. Matching cache "
        "geometry does not reproduce the full processor or its branch predictor. "
        "Counts below are modeled events; REP iterations differ from native "
        "retired-instruction counting. Data references mean reads plus writes; "
        "branches mean conditional plus indirect branches.",
        "",
        "| Workload | Instructions | Data references | Branches | "
        "Branch misses | D1 misses | LL misses |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for row in rows:
        if row["tool"] == "cachegrind":
            s = row["summary"]
            d = s["derived_counts"]
            lines.append(
                f"| `{row['workload']}` | {s['counts']['Ir']:,} | "
                f"{d['data_references']:,} | {d['branches']:,} | "
                f"{d['branch_mispredictions']:,} | "
                f"{d['D1_misses']:,} | {d['LL_misses']:,} |"
            )
    lines += [
        "",
        "Instruction attribution uses the function totals from `cg_annotate` "
        "at a 0.1% display threshold, including each function's source-file/inline "
        "attributions exactly once. These are instruction shares, "
        "not elapsed-time or Amdahl shares; optimized inlining also makes "
        "their categories differ from lexical diagnostic scopes.",
        "",
        "| Workload | Function | Modeled instruction share |",
        "| --- | --- | ---: |",
    ]
    for row in rows:
        if row["tool"] == "cachegrind":
            for function in row["functions_by_instructions"][:4]:
                share = 100 * function["instructions"] / row["summary"]["counts"]["Ir"]
                lines.append(
                    f"| `{row['workload']}` | `{function['function']}` | {share:.3f}% |"
                )
    lines += [
        "",
        "## Requested heap and allocation sites",
        "",
        "DHAT intercepts whole-process heap operations, including libc and "
        "shutdown. A reallocation adds a block and its entire new requested "
        "size; its stack remains attributed to the original site. Global "
        "heap peak is measured jointly, not by summing site-local peaks. "
        "Requested traffic and peak heap are not native RSS, allocation time "
        "or evidence of a leak. Lifetimes use modeled instructions. The local "
        "version-matched Cachegrind and DHAT manuals are hash-bound in the receipt.",
        "",
        "| Workload | Requested bytes | Allocation blocks incl. realloc | "
        "Peak live heap bytes | Grid-attributed traffic |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for row in rows:
        if row["tool"] == "dhat":
            s = row["summary"]
            grid_share = (
                100
                * row["integration_grid_requested_bytes"]
                / s["total_requested_bytes"]
            )
            lines.append(
                f"| `{row['workload']}` | {s['total_requested_bytes']:,} | "
                f"{s['total_allocation_blocks_including_realloc']:,} | "
                f"{s['peak_live_heap_bytes']:,} | {grid_share:.3f}% |"
            )
    lines += [
        "",
        "The JSON retains the ten largest individual allocation sites and "
        "their complete stacks, plus Rust-counter cross-checks with explicit "
        "scope differences. Grid-attributed traffic is summed over every DHAT "
        "program point whose stack includes `integration_grid`, not inferred "
        "from timing shares or only the displayed top sites.",
        "",
        "These baseline results support candidate prioritization. Exact "
        "scientific gates and paired uninstrumented native measurements "
        "remain required for an optimization claim.",
        "",
    ]
    document = REPO / "docs/performance/CORRECTED_COUNTERS.md"
    with document.open("x") as stream:
        stream.write("\n".join(lines))
    exact.replay.manifest(
        OUT / "report_receipt.json",
        {
            "helper": exact.oracle.file_record(Path(__file__)),
            "counter_manifest": exact.oracle.file_record(OUT / "manifest.json"),
            "outputs": [
                exact.oracle.file_record(target),
                exact.oracle.file_record(document),
            ],
        },
    )


if __name__ == "__main__":
    main()
