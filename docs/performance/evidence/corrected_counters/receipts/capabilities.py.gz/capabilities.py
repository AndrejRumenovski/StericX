#!/usr/bin/env python3
"""Fresh local Valgrind execution probes; no privilege changes."""

import json
import os
import subprocess
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
SNAPSHOT = BASE / "accurate_baseline_v1"
sys.path.insert(0, str(SNAPSHOT / "source/scripts"))
import scientifically_exact_optimization as exact  # noqa: E402
import profile_valgrind as vg  # noqa: E402


def main():
    diagnostics = exact.replay.load_manifest(
        BASE / "accurate_baseline_v1_diagnostics/builds.json"
    )
    symbols = exact.oracle.verify(diagnostics["binaries"]["symbols"]["stericx"])
    native = SNAPSHOT / "bin/native"
    install = Path("/tmp/stericx-valgrind-1000")
    binary, library = install / "usr/bin/valgrind.bin", install / "usr/libexec/valgrind"
    files = [
        binary,
        install / "usr/bin/cg_annotate",
        library / "cachegrind-amd64-linux",
        library / "dhat-amd64-linux",
        library / "vgpreload_core-amd64-linux.so",
        library / "vgpreload_dhat-amd64-linux.so",
        Path(__file__),
        symbols,
        native,
    ]
    bindings = [exact.oracle.file_record(path) for path in files]
    env = dict(
        os.environ,
        LC_ALL="C",
        TZ="UTC",
        OMP_NUM_THREADS="1",
        RAYON_NUM_THREADS="1",
        VALGRIND_LIB=str(library),
    )
    env.pop("STERICX_PROFILE_PATH", None)
    commands = []
    for name, argv in (
        ("version", [str(binary), "--version"]),
        ("native-version", [str(native), "--version"]),
        ("symbols-version", [str(symbols), "--version"]),
        (
            "cachegrind-probe",
            [
                str(binary),
                "--tool=cachegrind",
                "--cache-sim=yes",
                "--branch-sim=yes",
                "--I1=32768,8,64",
                "--D1=32768,8,64",
                "--LL=16777216,16,64",
                "--cachegrind-out-file=" + str(OUT / "probe.cachegrind"),
                str(symbols),
                "--version",
            ],
        ),
        (
            "dhat-probe",
            [
                str(binary),
                "--tool=dhat",
                "--mode=heap",
                "--dhat-out-file=" + str(OUT / "probe.dhat.json"),
                str(symbols),
                "--version",
            ],
        ),
    ):
        result = subprocess.run(argv, capture_output=True, env=env, timeout=120)
        stdout, stderr = OUT / (name + ".stdout"), OUT / (name + ".stderr")
        stdout.write_bytes(result.stdout)
        stderr.write_bytes(result.stderr)
        commands.append(
            {
                "argv": argv,
                "returncode": result.returncode,
                "stdout": exact.oracle.file_record(stdout),
                "stderr": exact.oracle.file_record(stderr),
            }
        )
        if (
            result.returncode
            or b"cannot be preloaded" in result.stderr
            or b"Fatal error" in result.stderr
        ):
            raise RuntimeError("local profiler probe failed: " + name)
    expected = (OUT / "native-version.stdout").read_bytes()
    if any(
        (OUT / (name + ".stdout")).read_bytes() != expected
        for name in ("symbols-version", "cachegrind-probe", "dhat-probe")
    ):
        raise ValueError("probe stdout differs from frozen native")
    capability = {
        "kind": "fresh_corrected_local_valgrind_capabilities",
        "valgrind_binary": str(binary),
        "VALGRIND_LIB": str(library),
        "cg_annotate": str(install / "usr/bin/cg_annotate"),
        "tool_version": (OUT / "version.stdout").read_text().strip(),
        "tool_files": bindings,
        "commands": commands,
        "cache_geometry": vg.sysfs_caches({2}),
        "cachegrind_probe": vg.parse_cachegrind(OUT / "probe.cachegrind"),
        "dhat_probe": vg.parse_dhat(OUT / "probe.dhat.json"),
        "root_hardware_probe": exact.oracle.file_record(
            BASE / "counter_capabilities_v1/manifest.json"
        ),
        "native_hardware_counters": False,
        "privileges_changed": False,
        "scientific_output_scope": "version probe only; each full workload remains checked against native",
    }
    for item in bindings:
        exact.oracle.verify(item)
    exact.replay.manifest(OUT / "capabilities.json", capability)
    print(capability["tool_version"] + ": cachegrind and DHAT probes pass", flush=True)


if __name__ == "__main__":
    main()
