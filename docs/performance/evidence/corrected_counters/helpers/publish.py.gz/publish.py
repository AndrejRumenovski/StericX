"""Publish compact exact counter evidence and source copies; never run the SUT."""

import gzip
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
REPO = BASE.parents[2]
DEST = REPO / "docs/performance/evidence/corrected_counters"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    DEST.mkdir(parents=True, exist_ok=False)
    counter = BASE / "corrected_counters_v1"
    work = BASE / "corrected_workloads_v2/valgrind"
    source = BASE / "accurate_baseline_v1/source"
    pairs = []
    for name in (
        "manifest.json",
        "report_receipt.json",
        "report_checks.json",
        "capabilities.json",
        "capabilities.py",
        "report.py",
        "test_report.py",
    ):
        pairs.append((counter / name, Path("receipts") / (name + ".gz")))
    pairs += [
        (
            BASE / "counter_capabilities_v1/manifest.json",
            Path("receipts/hardware_probe.json.gz"),
        ),
        (
            BASE / "accurate_baseline_v1_diagnostics/builds.json",
            Path("receipts/symbol_builds.json.gz"),
        ),
        (
            REPO / "docs/performance/current_corrected_counters.json",
            Path("receipts/compact_counter_data.json.gz"),
        ),
        (Path(__file__), Path("helpers/publish.py.gz")),
    ]
    for name in ("profile_valgrind.py", "profile_stericx.py", "profile_child.c"):
        pairs.append((source / "scripts" / name, Path("helpers") / (name + ".gz")))
    for p in sorted((source / "src").rglob("*.rs")):
        pairs.append((p, Path("source") / (str(p.relative_to(source)) + ".gz")))
    for name in ("Cargo.toml", "Cargo.lock"):
        pairs.append((source / name, Path("source") / (name + ".gz")))
    for tool in ("cachegrind", "dhat"):
        for suffix, case in (
            ("conformers56", "conformers_56"),
            ("screen1000", "screen_1000"),
            ("descriptors10000", "descriptors_10000"),
        ):
            label = f"accurate_baseline_{tool}_{suffix}_v1"
            directory = work / label
            names = (
                (
                    "summary.json",
                    "run.json",
                    "profiler.log",
                    "events.out",
                    "functions.txt",
                )
                if tool == "cachegrind"
                else ("summary.json", "run.json", "profiler.log", "dhat.json")
            )
            for name in names:
                pairs.append(
                    (directory / case / name, Path("runs") / label / (name + ".gz"))
                )
    records = []
    for original, relative in pairs:
        data = original.read_bytes()
        compressed = gzip.compress(data, mtime=0)
        target = DEST / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(compressed)
        assert gzip.decompress(target.read_bytes()) == data
        records.append(
            {
                "original": {
                    "path": str(original),
                    "bytes": len(data),
                    "sha256": sha(data),
                },
                "archive": {
                    "path": str(relative),
                    "bytes": len(compressed),
                    "sha256": sha(compressed),
                },
                "encoding": "gzip with mtime=0; decompression restores exact original bytes",
            }
        )
    for row in records:
        assert (
            sha(Path(row["original"]["path"]).read_bytes()) == row["original"]["sha256"]
        )
    manifest = {
        "kind": "compact_corrected_counter_publication",
        "complete": True,
        "records": records,
        "native_processes_executed": 0,
        "not_a_standalone_scientific_admission": True,
        "scope": "All six modeled counter streams, run receipts, annotations, exact executed source and helpers. Full scientific stdout/input/native-oracle artifacts remain in the separately hash-bound original evidence tree.",
    }
    data = (json.dumps(manifest, indent=2) + "\n").encode()
    (DEST / "manifest.json").write_bytes(data)
    (DEST / "manifest.json.sha256").write_text(sha(data) + "  manifest.json\n")
    print(
        json.dumps(
            {
                "files": len(records),
                "compressed_bytes": sum(r["archive"]["bytes"] for r in records),
                "manifest_sha256": sha(data),
            }
        )
    )


if __name__ == "__main__":
    main()
